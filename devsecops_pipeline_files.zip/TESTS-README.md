# DevSecOps Pipeline - Test Files

## Expected project structure

backend/   -> Laravel
frontend/  -> Vue.js
api/       -> FastAPI
.github/workflows/ -> GitHub Actions

## Pipeline order

1. Laravel CI
2. Vue CI
3. FastAPI CI
4. Security scanning
5. Docker build
6. Docker image scan
7. Docker Hub push
8. Ubuntu deployment

## GitHub Secrets required later

DOCKERHUB_USERNAME
DOCKERHUB_TOKEN
SEMGREP_APP_TOKEN
SERVER_HOST
SERVER_USER
SERVER_SSH_KEY

## Important

These workflows are a starting template. Adjust PHP, Node, Python versions,
folder names, package scripts, Dockerfile paths, and database configuration
to match the actual project.

For the first exercise, run only:
01-laravel-ci.yml
02-vue-ci.yml
03-fastapi-ci.yml

After those pass, add security, then Docker, then deployment.
